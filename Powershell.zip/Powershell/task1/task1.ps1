param(
   [Parameter(Mandatory=$true)]
   [string]$ip_address_1,

   [Parameter(Mandatory=$true)]
   [string]$ip_address_2,

   [Parameter(Mandatory=$true)]
   [string]$network_mask
)


$ErrorActionPreference="Ignore"


# this function checks if ip addresses is valid or not
function IsValid($ip){
    if ($ip -match "^([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$") {
        return $true
     } else {
        return $false
     }
}

# Convert IP addresses and mask to integers
if (IsValid $ip_address_1){
    $IPAddress1Int = [BitConverter]::ToUInt32([System.Net.IPAddress]::Parse($ip_address_1).GetAddressBytes(), 0)
} else {
    write-host "$($ip_address_1) is not a valid IPv4 Address"
}
if (IsValid $ip_address_2){
    $IPAddress2Int = [BitConverter]::ToUInt32([System.Net.IPAddress]::Parse($ip_address_2).GetAddressBytes(), 0)
} else {
    write-host "$($ip_address_2) is not a valid IPv4 Address" 
}
if (IsValid $network_mask){
    $MaskAddressInt = [BitConverter]::ToUInt32([System.Net.IPAddress]::Parse($network_mask).GetAddressBytes(), 0)
} else {
    write-host "$($network_mask) is not a valid netmask"
}

# To catch errors
try{
    # Calculate network addresses
    $IPAddress1NetworkInt = $IPAddress1Int -band $MaskAddressInt 
    $IPAddress2NetworkInt = $IPAddress2Int -band $MaskAddressInt
} catch{
    Write-Output "Error"
}


# Compare network addresses is the same network or not
if ($IPAddress1NetworkInt -eq $IPAddress2NetworkInt) {
   Write-Output "Yes"
} else {
    Write-Output "No"
}
