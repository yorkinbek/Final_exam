$txtInfo = [cultureinfo]::InvariantCulture.TextInfo
$csv = Import-Csv ./accounts.csv

foreach($line in $csv) {
    $name = [string]$line.name

    # ToTitleCase for using Uppercase both firstname and surname
    $line.name  = $txtInfo.ToTitleCase($name)

    # '(?<=^\w{1})\w+\s' for getting first letters of firstname and all surname
    $line.email = ([string]($name -replace '(?<=^\w{1})\w+\s')).ToLower()+'@abc.com'
}

# -UseQuotes AsNeeded it works only above version of PowerShell 7
$csv | Export-Csv ./accounts_new.csv -UseQuotes AsNeeded


$csv = Import-Csv ./accounts_new.csv
$emails = @()  # array to save duplicate emails

# For loop to find duplicate emails
foreach($line in $csv) {
    $email = [string]$line.email
    # n is the number of duplicate emails
    $n = $csv | Where-Object { [string]$_.email -eq $email }
    if ($n.Count -gt 1 -and !($emails -contains $email)) {
        $emails += $email
    }
}

# Sorted emails 
$emails = $emails | Sort-Object

# for loop trough emails array and csv file to find intersection between rows and emails array's value
foreach($duplicate in $emails) {
    foreach($line in $csv) {
        $name = [string]$line.name
        $email = [string]$line.email
        if ($email -contains $duplicate) {
            $line.email = ([string]($name -replace '(?<=^\w{1})\w+\s')).ToLower()+[string]$line.location_id+'@abc.com'
        }
    }
}

$csv | Export-Csv ./accounts_new.csv -UseQuotes AsNeeded
