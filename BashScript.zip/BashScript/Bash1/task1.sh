#!/bin/bash

NEW_FILE=accounts_new.csv
FILE=accounts.csv

# setting default column names
echo "id,location_id,name,title,email,department" > $NEW_FILE
((c=-1))
IFS=$'\n'
for line in $(cat ${FILE})
do
    ((c++))
    if ((c==0))
    then
        continue
    fi

    # find lines seperated by quotation marks in title
    if echo "$line" | grep '"' ;then
        IFS='"' read -a title <<< ${line}
        longtitle="\"${title[1]}\""
    else
        IFS=',' read -a title <<< ${line}
        longtitle=${title[3]}
    fi

    IFS=',' read -a data <<< ${line}
    IFS=' ' read firstname lastname <<< ${data[2]}
    name=${firstname^}" "${lastname^}
    firstletter=${firstname::1}
    email=${firstletter,}${lastname,,}@abc.com
    echo "${data[0]},${data[1]},$name,$longtitle,$email,${data[5]}" >> $NEW_FILE
done

 # Find duplicated emails and sort them
duplicates=$(cut -d',' -f5 $NEW_FILE | sort | uniq -d)

# Find the duplicated emails with intersection of email array and row
for emails in $duplicates; do
    for line in $(cat ${NEW_FILE})
    do
        IFS=',' read -a data <<< ${line}
        IFS=' ' read firstname lastname <<< ${data[2]}
        name=${firstname^}" "${lastname^}
        firstletter=${firstname::1}
        email=${firstletter,}${lastname,,}${data[1]}@abc.com
        if [[ ${data[4]} == $emails ]] ;then
            # Update email using awk with row number
            awk -v row=$((${data[0]}+1)) -v email=$email -F ',' -v OFS=","  'NR==row{$5=email}1' $NEW_FILE > temp && mv temp  $NEW_FILE
        fi
    done
done