#!/bin/bash

FILE=output.txt
# Remove ---------- from text file 
sed --in-place '/---------------------------/d' $FILE
OUTPUT_FILE="${FILE%.*}.json"

((c=-1))
countLine=$(wc -l < "$FILE")
# Read file line by line
while IFS='' read -r line || [[ -n "$line" ]]; do
# Split line by space
    LINE_ARRAY=($line)
    ((c++))
# when c reach the 0  and first row can edit
    if ((c==0)) 
    then
        Name=${LINE_ARRAY[@]:1:${#LINE_ARRAY[@]} - 4}
        printf "{\n\"testName\":\"$Name\",\n\"tests\":[\n" >> $OUTPUT_FILE
        continue
    fi
# when c reach the last and before last row
    if ((c==$countLine-1))
    then
        Name=${LINE_ARRAY[@]:2:${#LINE_ARRAY[@]} - 3}
        printf "{\n\t\"name\":\"${Name::(-1)}\",\n\t\"status\":true,\n\t\"duration\":\"${LINE_ARRAY[${#LINE_ARRAY[@]} - 1]}\"\n}\n" >> $OUTPUT_FILE
        continue
    elif (($countLine == c))
    then
        # split last row by comma
        IFS=',' read -a summary <<< ${line} 

        #split first part of summary line
        IFS=' ' read -a succ <<< ${summary[0]}

        #split second part of summary line 
        IFS=' ' read -a fail <<< ${summary[1]}

        # split third part of summary line 
        IFS=' ' read -a rate <<< ${summary[2]}

        # split last part of summary line
        IFS=' ' read -a duration <<< ${summary[3]}

        # from succ array get first element and it is success number
        success=${succ[0]}

        # from fail array get first element and it is fail number 
        failed=${fail[0]}

        # from rate array get third element and it is rate number in at % persent and convert it to the int
        rating=${rate[2]/.*}
        
        # from duration array get second element and it is all the duration time
        time=${duration[1]}
        printf "],\n\"sumarry\":{\n\t\"success\":$success,\n\t\"failed\":$failed,\n\t\"rating\":$rating,\n\t\"duration\": \"$time\"\n\t}\n}" >> $OUTPUT_FILE
        break
    fi

    # when first part of row starts with "not ok"
    if [[ " ${LINE_ARRAY[*]} " =~ " not ok " ]]
    then
        Name=${LINE_ARRAY[@]:3:${#LINE_ARRAY[@]} - 4}
        printf "{\n\t\"name\":\"${Name::(-1)}\",\n\t\"status\":false,\n\t\"duration\":\"${LINE_ARRAY[${#LINE_ARRAY[@]} - 1]}\"\n},\n" >> $OUTPUT_FILE   
    else
        Name=${LINE_ARRAY[@]:2:${#LINE_ARRAY[@]} - 3}
        printf "{\n\t\"name\":\"${Name::(-1)}\",\n\t\"status\":true,\n\t\"duration\":\"${LINE_ARRAY[${#LINE_ARRAY[@]} - 1]}\"\n},\n" >> $OUTPUT_FILE
    fi

done < "$FILE"

